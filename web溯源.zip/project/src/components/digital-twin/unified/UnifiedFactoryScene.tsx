import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { ManufacturingArea } from './areas/ManufacturingArea';
import { SupplyChainArea } from './areas/SupplyChainArea';
import { DistributionArea } from './areas/DistributionArea';
import { EnterpriseArea } from './areas/EnterpriseArea';
import { ErrorBoundary } from '../ErrorBoundary';
import { UnifiedFactoryFallback } from './UnifiedFactoryFallback';

export const UnifiedFactoryScene = () => {
  return (
    <div className="w-full h-[80vh] bg-gray-100 rounded-lg overflow-hidden">
      <ErrorBoundary fallback={<UnifiedFactoryFallback />}>
        <Suspense fallback={<UnifiedFactoryFallback />}>
          <Canvas
            gl={{
              antialias: true,
              alpha: false,
              powerPreference: 'high-performance',
              failIfMajorPerformanceCaveat: false
            }}
            dpr={[1, 1.5]}
            camera={{
              position: [30, 30, 30],
              fov: 50,
              near: 0.1,
              far: 1000
            }}
            shadows={false}
            style={{ background: 'linear-gradient(to bottom, #87ceeb, #e0f4ff)' }}
          >
            {/* Lights */}
            <ambientLight intensity={0.8} />
            <directionalLight
              position={[10, 10, 10]}
              intensity={1}
              castShadow={false}
            />
            <hemisphereLight
              args={['#ffffff', '#80a0bc', 0.6]}
              position={[0, 50, 0]}
            />

            {/* Main Factory Complex */}
            <group position={[0, 0, 0]}>
              <ManufacturingArea position={[-10, 0, -10]} />
              <SupplyChainArea position={[10, 0, -10]} />
              <DistributionArea position={[-10, 0, 10]} />
              <EnterpriseArea position={[10, 0, 10]} />
            </group>

            {/* Ground */}
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
              <planeGeometry args={[100, 100]} />
              <meshStandardMaterial color="#a3b3c3" />
            </mesh>

            <OrbitControls
              enablePan={true}
              enableZoom={true}
              minDistance={10}
              maxDistance={50}
              maxPolarAngle={Math.PI / 2.1}
              makeDefault
            />
          </Canvas>
        </Suspense>
      </ErrorBoundary>
    </div>
  );
};
import React from 'react';
import { RoundedBox, Cylinder, Sphere } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ManufacturingAreaProps {
  position?: [number, number, number];
}

export const ManufacturingArea: React.FC<ManufacturingAreaProps> = ({ position = [0, 0, 0] }) => {
  const chimneyRef = React.useRef<THREE.Group>(null);
  
  useFrame(({ clock }) => {
    if (chimneyRef.current) {
      const smoke = chimneyRef.current.children[1] as THREE.Mesh;
      smoke.position.y = Math.sin(clock.getElapsedTime()) * 0.2 + 2;
      smoke.scale.setScalar(1 + Math.sin(clock.getElapsedTime() * 2) * 0.1);
    }
  });

  return (
    <group position={new THREE.Vector3(...position)}>
      {/* Main Production Building */}
      <RoundedBox args={[8, 6, 12]} position={[0, 3, 0]}>
        <meshStandardMaterial color="#4a90e2" metalness={0.4} roughness={0.6} />
      </RoundedBox>

      {/* Chimneys */}
      <group ref={chimneyRef}>
        <Cylinder args={[0.4, 0.5, 8]} position={[2, 7, -2]}>
          <meshStandardMaterial color="#718096" roughness={0.7} />
        </Cylinder>
        <Sphere args={[0.8]} position={[2, 11, -2]}>
          <meshStandardMaterial
            color="#cbd5e0"
            transparent
            opacity={0.6}
            roughness={0.1}
          />
        </Sphere>
      </group>

      {/* Production Line */}
      <RoundedBox args={[2, 1, 8]} position={[-2, 0.5, 0]}>
        <meshStandardMaterial color="#ed8936" metalness={0.4} roughness={0.6} />
      </RoundedBox>

      {/* Control Room */}
      <RoundedBox args={[3, 4, 3]} position={[3, 2, 4]}>
        <meshStandardMaterial color="#4299e1" metalness={0.5} roughness={0.5} />
      </RoundedBox>
    </group>
  );
};
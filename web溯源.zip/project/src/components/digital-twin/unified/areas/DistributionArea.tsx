import React from 'react';
import { RoundedBox } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface DistributionAreaProps {
  position?: [number, number, number];
}

export const DistributionArea: React.FC<DistributionAreaProps> = ({ position = [0, 0, 0] }) => {
  const vehicleRef = React.useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    if (vehicleRef.current) {
      vehicleRef.current.position.x = Math.sin(clock.getElapsedTime() * 0.5) * 4;
    }
  });

  return (
    <group position={new THREE.Vector3(...position)}>
      {/* Distribution Center */}
      <RoundedBox args={[10, 4, 6]} position={[0, 2, 0]} castShadow>
        <meshStandardMaterial color="#9f7aea" metalness={0.4} roughness={0.6} />
      </RoundedBox>

      {/* Loading Bays */}
      <RoundedBox args={[12, 0.5, 8]} position={[0, 0.25, 4]} castShadow>
        <meshStandardMaterial color="#a0aec0" />
      </RoundedBox>

      {/* Moving Vehicle */}
      <group ref={vehicleRef} position={[0, 0.5, 6]}>
        <RoundedBox args={[2, 1.5, 1]} castShadow>
          <meshStandardMaterial color="#f56565" metalness={0.5} roughness={0.5} />
        </RoundedBox>
      </group>

      {/* Office Section */}
      <RoundedBox args={[4, 6, 4]} position={[-4, 3, -2]} castShadow>
        <meshStandardMaterial color="#805ad5" metalness={0.6} roughness={0.4} />
      </RoundedBox>
    </group>
  );
};
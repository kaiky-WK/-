import React from 'react';
import { RoundedBox, Cylinder } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface SupplyChainAreaProps {
  position?: [number, number, number];
}

export const SupplyChainArea: React.FC<SupplyChainAreaProps> = ({ position = [0, 0, 0] }) => {
  const containerRef = React.useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    if (containerRef.current) {
      containerRef.current.children.forEach((child, index) => {
        child.position.y = Math.sin(clock.getElapsedTime() + index) * 0.1 + 2;
      });
    }
  });

  return (
    <group position={new THREE.Vector3(...position)}>
      {/* Warehouse */}
      <RoundedBox args={[12, 5, 8]} position={[0, 2.5, 0]} castShadow>
        <meshStandardMaterial color="#68d391" metalness={0.3} roughness={0.7} />
      </RoundedBox>

      {/* Storage Containers */}
      <group ref={containerRef}>
        <RoundedBox args={[2, 2, 2]} position={[-4, 2, -2]} castShadow>
          <meshStandardMaterial color="#f6ad55" />
        </RoundedBox>
        <RoundedBox args={[2, 2, 2]} position={[-4, 2, 0]} castShadow>
          <meshStandardMaterial color="#f6ad55" />
        </RoundedBox>
        <RoundedBox args={[2, 2, 2]} position={[-4, 2, 2]} castShadow>
          <meshStandardMaterial color="#f6ad55" />
        </RoundedBox>
      </group>

      {/* Loading Dock */}
      <RoundedBox args={[14, 0.5, 4]} position={[0, 0.25, 6]} castShadow>
        <meshStandardMaterial color="#a0aec0" />
      </RoundedBox>

      {/* Storage Silos */}
      <Cylinder args={[1.5, 1.5, 8]} position={[4, 4, -2]} castShadow>
        <meshStandardMaterial color="#cbd5e0" metalness={0.6} roughness={0.4} />
      </Cylinder>
      <Cylinder args={[1.5, 1.5, 8]} position={[4, 4, 2]} castShadow>
        <meshStandardMaterial color="#cbd5e0" metalness={0.6} roughness={0.4} />
      </Cylinder>
    </group>
  );
};
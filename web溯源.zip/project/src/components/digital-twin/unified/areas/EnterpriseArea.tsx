import React from 'react';
import { RoundedBox, Cylinder } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface EnterpriseAreaProps {
  position?: [number, number, number];
}

export const EnterpriseArea: React.FC<EnterpriseAreaProps> = ({ position = [0, 0, 0] }) => {
  const antennaRef = React.useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    if (antennaRef.current) {
      antennaRef.current.rotation.y = clock.getElapsedTime() * 0.5;
    }
  });

  return (
    <group position={new THREE.Vector3(...position)}>
      {/* Main Office Tower */}
      <RoundedBox args={[8, 12, 8]} position={[0, 6, 0]} castShadow>
        <meshStandardMaterial
          color="#2d3748"
          metalness={0.7}
          roughness={0.3}
          envMapIntensity={1}
        />
      </RoundedBox>

      {/* Glass Panels */}
      {[-2, 0, 2].map((x, i) => (
        <RoundedBox key={i} args={[1.5, 10, 0.1]} position={[x, 6, 4.1]} castShadow>
          <meshStandardMaterial
            color="#90cdf4"
            metalness={0.9}
            roughness={0.1}
            transparent
            opacity={0.5}
          />
        </RoundedBox>
      ))}

      {/* Rotating Antenna */}
      <group ref={antennaRef} position={[0, 12.5, 0]}>
        <Cylinder args={[0.1, 0.1, 3]} position={[0, 1.5, 0]} castShadow>
          <meshStandardMaterial color="#e53e3e" />
        </Cylinder>
        <RoundedBox args={[2, 0.2, 0.2]} position={[0, 2.5, 0]} castShadow>
          <meshStandardMaterial color="#e53e3e" />
        </RoundedBox>
      </group>

      {/* Entrance */}
      <RoundedBox args={[4, 3, 2]} position={[0, 1.5, 4]} castShadow>
        <meshStandardMaterial
          color="#4a5568"
          metalness={0.6}
          roughness={0.4}
        />
      </RoundedBox>
    </group>
  );
};
import React from 'react';
import { Factory, Truck, Store, Building } from 'lucide-react';

export const UnifiedFactoryFallback = () => {
  return (
    <div className="w-full h-[80vh] bg-gray-100 rounded-lg flex items-center justify-center">
      <div className="grid grid-cols-2 gap-8 p-8">
        <div className="flex flex-col items-center space-y-2">
          <Factory className="w-16 h-16 text-blue-600" />
          <span className="text-sm font-medium">生产区域</span>
        </div>
        <div className="flex flex-col items-center space-y-2">
          <Truck className="w-16 h-16 text-green-600" />
          <span className="text-sm font-medium">供应链区域</span>
        </div>
        <div className="flex flex-col items-center space-y-2">
          <Store className="w-16 h-16 text-purple-600" />
          <span className="text-sm font-medium">配送区域</span>
        </div>
        <div className="flex flex-col items-center space-y-2">
          <Building className="w-16 h-16 text-orange-600" />
          <span className="text-sm font-medium">企业总部</span>
        </div>
      </div>
    </div>
  );
};
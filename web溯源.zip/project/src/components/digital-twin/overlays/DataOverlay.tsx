import React from 'react';
import { useDigitalTwin } from '../../../contexts/DigitalTwinContext';

interface DataOverlayProps {
  area: 'manufacturing' | 'supplyChain' | 'distribution' | 'enterprise';
  position: { x: number; y: number };
}

const getMetricColor = (value: number): string => {
  if (value >= 90) return 'text-green-500';
  if (value >= 80) return 'text-blue-500';
  if (value >= 70) return 'text-yellow-500';
  return 'text-red-500';
};

export const DataOverlay: React.FC<DataOverlayProps> = ({ area, position }) => {
  const { metrics } = useDigitalTwin();
  const areaMetrics = metrics[area];

  const metricLabels = {
    manufacturing: {
      equipmentStatus: '设备状态',
      productionEfficiency: '生产效率',
      qualityControl: '质量控制',
      maintenanceWarning: '维护预警'
    },
    supplyChain: {
      inventory: '库存状态',
      logistics: '物流追踪',
      supplierRating: '供应商评级',
      procurement: '采购预测'
    },
    distribution: {
      salesChannels: '销售渠道',
      marketDemand: '市场需求',
      pricingDynamics: '价格动态',
      deliveryRoutes: '配送路线'
    },
    enterprise: {
      tracking: '全链追踪',
      qualitySafety: '质量安全',
      costBenefit: '成本效益',
      riskWarning: '风险预警'
    }
  };

  return (
    <div
      className="absolute bg-white/90 rounded-lg shadow-lg p-3 text-sm"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        transform: 'translate(-50%, -100%)',
        minWidth: '160px'
      }}
    >
      {Object.entries(areaMetrics).map(([key, value]) => (
        <div key={key} className="flex justify-between items-center mb-1">
          <span className="text-gray-600">{metricLabels[area][key]}</span>
          <span className={`font-semibold ${getMetricColor(value)}`}>
            {value.toFixed(1)}%
          </span>
        </div>
      ))}
    </div>
  );
};
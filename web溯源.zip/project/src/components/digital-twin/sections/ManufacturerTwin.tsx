import React from 'react';
import { MetricCard } from '../metrics/MetricCard';

export const ManufacturerTwin = () => {
  const metrics = [
    {
      title: '设备运行状态',
      value: 95.5,
      status: 'normal' as const,
      trend: 2.3
    },
    {
      title: '生产线效率',
      value: 87.2,
      status: 'warning' as const,
      trend: -1.5
    },
    {
      title: '质量控制指标',
      value: 98.1,
      status: 'normal' as const,
      trend: 0.8
    },
    {
      title: '设备维护预警',
      value: 75.3,
      status: 'warning' as const,
      trend: -3.2
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>
    </div>
  );
};
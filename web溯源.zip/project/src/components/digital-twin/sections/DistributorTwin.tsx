import React from 'react';
import { MetricCard } from '../metrics/MetricCard';

export const DistributorTwin = () => {
  const metrics = [
    {
      title: '销售渠道分析',
      value: 89.7,
      status: 'normal' as const,
      trend: 2.8
    },
    {
      title: '市场需求预测',
      value: 93.4,
      status: 'normal' as const,
      trend: 1.5
    },
    {
      title: '价格动态调整',
      value: 78.6,
      status: 'warning' as const,
      trend: -2.3
    },
    {
      title: '配送路线优化',
      value: 85.9,
      status: 'normal' as const,
      trend: 0.9
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>
    </div>
  );
};
import React from 'react';
import { MetricCard } from '../metrics/MetricCard';

export const EnterpriseTwin = () => {
  const metrics = [
    {
      title: '全链路追踪',
      value: 96.3,
      status: 'normal' as const,
      trend: 1.2
    },
    {
      title: '质量安全监控',
      value: 92.8,
      status: 'normal' as const,
      trend: 0.7
    },
    {
      title: '成本效益分析',
      value: 84.5,
      status: 'warning' as const,
      trend: -1.8
    },
    {
      title: '风险预警',
      value: 71.2,
      status: 'error' as const,
      trend: -5.4
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>
    </div>
  );
};
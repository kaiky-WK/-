import React from 'react';
import { MetricCard } from '../metrics/MetricCard';

export const SupplierTwin = () => {
  const metrics = [
    {
      title: '库存实时监控',
      value: 82.5,
      status: 'warning' as const,
      trend: -4.2
    },
    {
      title: '物流追踪',
      value: 94.8,
      status: 'normal' as const,
      trend: 1.7
    },
    {
      title: '供应商评估',
      value: 88.9,
      status: 'normal' as const,
      trend: 2.1
    },
    {
      title: '采购预测',
      value: 91.2,
      status: 'normal' as const,
      trend: 3.4
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>
    </div>
  );
};
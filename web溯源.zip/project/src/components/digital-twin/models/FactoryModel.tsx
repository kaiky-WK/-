import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Box, Cylinder, Grid } from '@react-three/drei';
import * as THREE from 'three';

const Building = ({ position, scale, color }) => (
  <Box args={[1, 2, 1]} position={position} scale={scale}>
    <meshStandardMaterial color={color} />
  </Box>
);

const Chimney = ({ position }) => (
  <Cylinder args={[0.2, 0.3, 1.5, 8]} position={position}>
    <meshStandardMaterial color="#666" />
  </Cylinder>
);

const Factory = ({ color = '#4f46e5', status = 'normal' }) => {
  const groupRef = useRef();

  useFrame(({ clock }) => {
    if (status === 'warning' || status === 'error') {
      groupRef.current.rotation.y = Math.sin(clock.getElapsedTime()) * 0.02;
    }
  });

  const statusColors = {
    normal: new THREE.Color(color),
    warning: new THREE.Color('#ca8a04'),
    error: new THREE.Color('#dc2626'),
  };

  return (
    <group ref={groupRef}>
      {/* Main Factory Building */}
      <Building 
        position={[0, 0.5, 0]} 
        scale={[3, 1, 2]} 
        color={statusColors[status]} 
      />
      
      {/* Office Building */}
      <Building 
        position={[-1.5, 0.75, 1]} 
        scale={[1, 1.5, 1]} 
        color={statusColors[status]} 
      />
      
      {/* Warehouse */}
      <Building 
        position={[1.5, 0.4, -1]} 
        scale={[2, 0.8, 1.5]} 
        color={statusColors[status]} 
      />
      
      {/* Chimneys */}
      <Chimney position={[0.5, 1.5, 0]} />
      <Chimney position={[-0.5, 1.5, 0]} />
      
      {/* Ground */}
      <Grid
        args={[20, 20]}
        position={[0, -0.01, 0]}
        cellSize={0.5}
        cellThickness={0.5}
        cellColor="#6b7280"
        sectionSize={3}
        fadeDistance={30}
        fadeStrength={1}
      />
    </group>
  );
};

interface FactoryModelProps {
  color?: string;
  status?: 'normal' | 'warning' | 'error';
}

export const FactoryModel: React.FC<FactoryModelProps> = ({ 
  color = '#4f46e5',
  status = 'normal'
}) => {
  return (
    <Canvas
      camera={{ position: [5, 5, 5], fov: 50 }}
      shadows
    >
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[5, 5, 5]}
        castShadow
        intensity={1}
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      <Factory color={color} status={status} />
      <OrbitControls
        enableZoom={true}
        minDistance={3}
        maxDistance={10}
        maxPolarAngle={Math.PI / 2}
      />
    </Canvas>
  );
};
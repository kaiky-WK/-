import React, { Suspense } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { UnifiedFactoryScene } from './unified/UnifiedFactoryScene';
import { ErrorBoundary } from './ErrorBoundary';
import { UnifiedFactoryFallback } from './unified/UnifiedFactoryFallback';
import { DigitalTwinProvider } from '../../contexts/DigitalTwinContext';

export const DigitalTwin = () => {
  const { user } = useAuth();

  const roleLabels = {
    manufacturer: '生产设备数字孪生',
    supplier: '供应链数字孪生',
    distributor: '销售网络数字孪生',
    enterprise: '企业运营数字孪生'
  };

  return (
    <DigitalTwinProvider>
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6">
          {user ? roleLabels[user.role] : '数字孪生系统'}
        </h2>
        <ErrorBoundary fallback={<UnifiedFactoryFallback />}>
          <Suspense fallback={<UnifiedFactoryFallback />}>
            <UnifiedFactoryScene />
          </Suspense>
        </ErrorBoundary>
      </div>
    </DigitalTwinProvider>
  );
};
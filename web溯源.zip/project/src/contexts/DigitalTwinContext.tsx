import React, { createContext, useContext, useState, useEffect } from 'react';

interface AreaMetrics {
  manufacturing: {
    equipmentStatus: number;
    productionEfficiency: number;
    qualityControl: number;
    maintenanceWarning: number;
  };
  supplyChain: {
    inventory: number;
    logistics: number;
    supplierRating: number;
    procurement: number;
  };
  distribution: {
    salesChannels: number;
    marketDemand: number;
    pricingDynamics: number;
    deliveryRoutes: number;
  };
  enterprise: {
    tracking: number;
    qualitySafety: number;
    costBenefit: number;
    riskWarning: number;
  };
}

interface DigitalTwinContextType {
  metrics: AreaMetrics;
  updateMetrics: (area: keyof AreaMetrics, key: string, value: number) => void;
}

const DigitalTwinContext = createContext<DigitalTwinContextType | undefined>(undefined);

export const DigitalTwinProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [metrics, setMetrics] = useState<AreaMetrics>({
    manufacturing: {
      equipmentStatus: 95.5,
      productionEfficiency: 87.2,
      qualityControl: 98.1,
      maintenanceWarning: 75.3
    },
    supplyChain: {
      inventory: 82.5,
      logistics: 94.8,
      supplierRating: 88.9,
      procurement: 91.2
    },
    distribution: {
      salesChannels: 89.7,
      marketDemand: 93.4,
      pricingDynamics: 78.6,
      deliveryRoutes: 85.9
    },
    enterprise: {
      tracking: 96.3,
      qualitySafety: 92.8,
      costBenefit: 84.5,
      riskWarning: 71.2
    }
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        manufacturing: {
          ...prev.manufacturing,
          equipmentStatus: prev.manufacturing.equipmentStatus + (Math.random() - 0.5) * 2
        },
        supplyChain: {
          ...prev.supplyChain,
          inventory: prev.supplyChain.inventory + (Math.random() - 0.5) * 2
        },
        distribution: {
          ...prev.distribution,
          salesChannels: prev.distribution.salesChannels + (Math.random() - 0.5) * 2
        },
        enterprise: {
          ...prev.enterprise,
          tracking: prev.enterprise.tracking + (Math.random() - 0.5) * 2
        }
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const updateMetrics = (area: keyof AreaMetrics, key: string, value: number) => {
    setMetrics(prev => ({
      ...prev,
      [area]: {
        ...prev[area],
        [key]: value
      }
    }));
  };

  return (
    <DigitalTwinContext.Provider value={{ metrics, updateMetrics }}>
      {children}
    </DigitalTwinContext.Provider>
  );
};

export const useDigitalTwin = () => {
  const context = useContext(DigitalTwinContext);
  if (context === undefined) {
    throw new Error('useDigitalTwin must be used within a DigitalTwinProvider');
  }
  return context;
};